/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2;

/**
 *
 * @author Allan Flores
 */

/**
 *
 * @author Allan Flores
 */
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import javax.swing.*;

public class Ejercicio2 extends JFrame{
 JLabel JL_id, JL_ComboBox, JL_texto, JL_precio;
 JTextField JT_id, JT_texto, JT_precio;
 JButton btn_calcdev;
 JComboBox CB_ComboBox;
 public Ejercicio2(){
     super("Ejercicio 2 by AllanDev");
     //Etiquetas
     JL_id = new JLabel("Ingrese Número #1:");
     JL_ComboBox = new JLabel("Seleccionar Operación:");
     JL_texto = new JLabel("Ingrese Numero #2:");
     JL_precio = new JLabel("Resultado");
     //Propiedades de Etiquetas
     JL_id.setBounds(20, 20, 100, 20);
        JL_texto.setBounds(20, 50, 100, 20);
            JL_ComboBox.setBounds(20, 80, 100, 20);
                    JL_precio.setBounds(20, 150, 80, 20);

                        
//Inicialización de JThings
     CB_ComboBox = new JComboBox();
                    btn_calcdev= new JButton("Calcular");
                            JT_texto = new JTextField(20);
                            JT_id = new JTextField(20);
                            JT_precio = new JTextField(20);
                                
     //Propiedades de los Objetos
     JT_id.setBounds(150,20,150,20);
     
          JT_texto.setBounds(150, 50, 150, 20);
          
     CB_ComboBox.setBounds(150, 80, 150, 20);
     CB_ComboBox.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Sumar", "Restar", "Multiplicar", "Dividir" }));
     
     JT_precio.setBounds(150, 150, 150 ,20);

     
          btn_calcdev.setBounds(300, 270, 80, 20);
     setLayout(null);
     
     
     //Agregando los Objetos al JFrame
     add(JL_ComboBox);
     add(JL_id);
     add(JT_id);
     add(btn_calcdev);
     add(CB_ComboBox);
     add(JL_texto);
     add(JT_texto);
     add(JL_precio);
     add(JT_precio);
     
       btn_calcdev.addActionListener(new  ActionListener() {

         public void actionPerformed(ActionEvent e) {
             
             try{
        Object X = CB_ComboBox.getSelectedItem(); 
	Object number = X;
        System.out.println(X);
        String var = String.valueOf(CB_ComboBox.getSelectedItem());
                     if(var=="Sumar"){
                 int numX = Integer.parseInt(JT_id.getText());
                 int numY = Integer.parseInt(JT_texto.getText());
                 int resultado = numX+numY;
                 System.out.println(resultado);
                 JT_precio.setText(Integer.toString(resultado));
             }else{
                if(var=="Restar"){
                 int numX = Integer.parseInt(JT_id.getText());
                 int numY = Integer.parseInt(JT_texto.getText());
                 int resultado = numX-numY;
                 System.out.println(resultado);
                 JT_precio.setText(Integer.toString(resultado));
             }else{
             if(var=="Multiplicar"){
                 int numX = Integer.parseInt(JT_id.getText());
                 int numY = Integer.parseInt(JT_texto.getText());
                 int resultado = numX*numY;
                 System.out.println(resultado);
                 JT_precio.setText(Integer.toString(resultado));
             }else{
                 if(var=="Dividir"){
                 int numX = Integer.parseInt(JT_id.getText());
                 int numY = Integer.parseInt(JT_texto.getText());
                 int resultado = numX/numY;
                 System.out.println(resultado);
                 JT_precio.setText(Integer.toString(resultado));
             }else{
             
                     if(var=="None"){
                 int precio = 1;
                 System.out.println(precio);
                 JT_precio.setText(Integer.toString(precio));
             }else{
             
             }
             }
             
             }
             }
             }
             }
             catch(Exception ex){}
         }
     });
     
     setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     setVisible(true);
     setLocationRelativeTo(null);
     setSize(500,400);

    
 }
 

 //Conexión SQL
  public void theQuery(String query){
      Connection con = null;
      Statement st = null;
      try{
          con = DriverManager.getConnection("jdbc:mysql://172.245.87.19/transactions","AllanDev","XFioresX007");
          st = con.createStatement();
          st.executeUpdate(query);
          JOptionPane.showMessageDialog(null,"Datos Guardados Correctamente");
      }catch(Exception ex){
          JOptionPane.showMessageDialog(null,ex.getMessage());
      }
  }
 
 
     public static void main(String[] args){
     
         new  Ejercicio2();
     }
}
      

